<h1>Ejercicio 2 Examen</h1>
<p>Página inicio que no hace nada</p>

